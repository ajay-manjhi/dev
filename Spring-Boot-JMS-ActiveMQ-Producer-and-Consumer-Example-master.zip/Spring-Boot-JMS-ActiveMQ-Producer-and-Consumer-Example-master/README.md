# Spring Boot JMS ActiveMQ Producer and Consumer Example
Spring Boot JMS ActiveMQ Producer and Consumer Example

Spring boot JMS ActiveMQ example from scratch - Step by step guide.
https://www.netsurfingzone.com/spring-boot/spring-boot-jms-activemq-producer-and-consumer-example/

This tutorial covers:-
1. How to send User defined message in JSON format.
2. How to create conusmer endpoint to receive message from ActiveMQ.
