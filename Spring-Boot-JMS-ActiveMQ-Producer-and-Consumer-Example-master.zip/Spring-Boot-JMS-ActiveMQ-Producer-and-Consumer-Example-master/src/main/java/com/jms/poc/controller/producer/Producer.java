package com.jms.poc.controller.producer;

import javax.jms.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jms.poc.pojo.Message;

@RestController
@RequestMapping("/produce")
public class Producer {
	private static final Logger logger = LoggerFactory.getLogger(Producer.class);

	@Autowired
	private JmsTemplate jmsTemplate;

	@Autowired
	private Queue queue;

	@PostMapping("/message")
	public Message sendMessage(@RequestBody Message message) {

		try {
			ObjectMapper mapper = new ObjectMapper();
			String messageStr = mapper.writeValueAsString(message);
			logger.debug("Produced and sent message : " + messageStr);
			jmsTemplate.convertAndSend(queue, messageStr);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}
}
