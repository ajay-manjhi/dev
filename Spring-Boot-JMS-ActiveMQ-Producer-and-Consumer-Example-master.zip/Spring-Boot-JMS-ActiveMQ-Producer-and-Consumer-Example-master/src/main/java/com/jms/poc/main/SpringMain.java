package com.jms.poc.main;

import org.apache.activemq.broker.jmx.DestinationViewMBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerEndpointRegistry;
import org.springframework.jms.config.SimpleJmsListenerEndpoint;
import org.springframework.jms.core.JmsTemplate;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXServiceURL;

@SpringBootApplication
@ComponentScan(basePackages = "com.jms.poc.*")

public class SpringMain {

	@Autowired
	JmsTemplate jmsTemplate;

	@Autowired
	DefaultJmsListenerContainerFactory jmsListenerContainerFactory;

	@Autowired
	ApplicationContext applicationContext;


	public static void main(String[] args) {
		SpringApplication.run(SpringMain.class, args);

		/*final JmsListenerEndpointRegistry endpointRegistry = new JmsListenerEndpointRegistry();

		final String destination = "register";
		final String messageText = "hello";

		// When: Endpoint registered then send
		SimpleJmsListenerEndpoint endpoint = new SimpleJmsListenerEndpoint();
		endpoint.setId("register");
		endpoint.setDestination(destination);
		endpoint.setMessageListener(m -> {
			testContext.completeNow();
		});

		endpointRegistry.registerListenerContainer(endpoint, jmsListenerContainerFactory);
		endpointRegistry.setApplicationContext(applicationContext);
		endpointRegistry.start();*/
	}

	/*static
	{
		// connection
		String url = "service:jmx:rmi:///jndi/rmi://localhost:1099/jmxrmi";
		JMXConnector connector = JMXConnectorFactory.connect(new JMXServiceURL(url));
		MBeanServerConnection connection = connector.getMBeanServerConnection();
		// get queue size
		ObjectName nameConsumers = new ObjectName("org.apache.activemq:type=Broker,brokerName=localhost,destinationType=Queue,destinationName=myqueue");
		DestinationViewMBean mbView = MBeanServerInvocationHandler.newProxyInstance(connection, nameConsumers, DestinationViewMBean.class, true);
		long queueSize = mbView.getQueueSize();
	}*/

}
