package com.jms.poc.controller.consumer;


import javax.jms.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.config.JmsListenerEndpointRegistry;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jms.poc.pojo.Message;

import java.util.Set;

@RestController
@RequestMapping("/consume")
public class Consumer {

	private static final Logger logger = LoggerFactory.getLogger(Consumer.class);

	@Autowired
	JmsListenerEndpointRegistry jmsListenerEndpointRegistry;

	@Autowired
	private JmsTemplate jmsTemplate;

	@Autowired
	private Queue queue;

	@GetMapping("/message")
	public Message consumeMessage() {

		if (!jmsListenerEndpointRegistry.isRunning()) {
			Set<String> set = jmsListenerEndpointRegistry.getListenerContainerIds();
			set.forEach(s -> s.toCharArray().toString());
			logger.error("JMS queue is paused...", set.size());
			return null;
		}

		Message message = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String jsonMessage = (String) jmsTemplate.receiveAndConvert(queue);
			message = mapper.readValue(jsonMessage, Message.class);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}
}








/*
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

	private static final Logger logger = LoggerFactory.getLogger(Consumer.class);

	@JmsListener(destination = "my-jms-queue")
	public void consumeMessage(String message) {
		logger.info("Message received from my activemq queue---"+message);
	}
}*/
