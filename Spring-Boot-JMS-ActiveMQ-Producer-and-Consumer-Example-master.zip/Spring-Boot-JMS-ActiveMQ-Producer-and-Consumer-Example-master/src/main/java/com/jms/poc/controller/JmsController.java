package com.jms.poc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.config.JmsListenerEndpointRegistry;
import org.springframework.jms.listener.AbstractJmsListeningContainer;
import org.springframework.jms.listener.MessageListenerContainer;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/jms")
public class JmsController {

    private static final Logger logger = LoggerFactory.getLogger(JmsController.class);

    @Autowired
    JmsListenerEndpointRegistry jmsListenerEndpointRegistry;


    @GetMapping("/stop")
    public String stopJmsListener() {
        if (jmsListenerEndpointRegistry.isRunning()) {
            jmsListenerEndpointRegistry.stop();
            logger.error("--------- JMS paused ----------");
            return "Jms Listener Stopped";
        }
        logger.error("--------- JMS already paused ----------");
        return "Jms Listener already Stopped";
    }

    @GetMapping("/start")
    public String startJmsListener() {
        if (jmsListenerEndpointRegistry.isRunning()) {
            logger.error("--------- Jms Listener already Running ----------");
            return "Jms Listener already Running";
        }
        for (MessageListenerContainer container : jmsListenerEndpointRegistry.getListenerContainers()) {
            ((AbstractJmsListeningContainer) container).setAutoStartup(true);
        }

        jmsListenerEndpointRegistry.start();
        logger.error("--------- JMS is started ----------");
        logger.error("----------JMS running ?-------- : "+ jmsListenerEndpointRegistry.isRunning());
        return "Jms Listener Started";
    }

}